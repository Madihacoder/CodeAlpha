package org.aacish.disease_prediction.test;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

import org.aacish.disease_prediction.DAO.AppDAOService;
import org.aacish.disease_prediction.DAO.VocabDAOService;

@SuppressWarnings("unused")
public class Hello {
	 
	
	
	  public static void main(String[] args) {
			
			
	  }
	 
	  
	 
	}
