package org.aacish.disease_prediction.test;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import org.aacish.disease_prediction.DAO.VocabDAO;
import org.aacish.disease_prediction.DAO.VocabDAOService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SuppressWarnings("unused")
public class ReaderTest {
	public static void main(String[] args) throws IOException{
//		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
//		VocabDAO vocabDao = (VocabDAO)context.getBean("vocabDAO");
		//System.out.println(vocabDao.getVocabulary());
		
	}
}
