package org.aacish.disease_prediction.model;

public class TrainingDocs {
	private String doc1 = "";
	private String doc2 = "";
	private String doc3 = "";
	private String doc4 = "";
	private String doc5 = "";
	private String aboutDisease = "";
	
	public String getDoc1() {
		return doc1;
	}
	public void setDoc1(String doc1) {
		this.doc1 = doc1;
	}
	public String getDoc2() {
		return doc2;
	}
	public void setDoc2(String doc2) {
		this.doc2 = doc2;
	}
	public String getDoc3() {
		return doc3;
	}
	public void setDoc3(String doc3) {
		this.doc3 = doc3;
	}
	public String getDoc4() {
		return doc4;
	}
	public void setDoc4(String doc4) {
		this.doc4 = doc4;
	}
	public String getDoc5() {
		return doc5;
	}
	public void setDoc5(String doc5) {
		this.doc5 = doc5;
	}
	public String getAboutDisease() {
		return aboutDisease;
	}
	public void setAboutDisease(String aboutDisease) {
		this.aboutDisease = aboutDisease;
	}
	
}
