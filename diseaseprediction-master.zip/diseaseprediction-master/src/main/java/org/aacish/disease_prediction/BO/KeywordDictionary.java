package org.aacish.disease_prediction.BO;

import java.util.List;

public interface KeywordDictionary {
	
	public List<String> loadInputKeywords(String input);
	
	
}
