# diseaseprediction
Undergrad final year project to predict diseases given any text symptoms.
A simple Java Spring app for disease prediction by using NLP. It predicts top 5 dieases given text symptomps.
