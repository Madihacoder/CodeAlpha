# Credits

FER+ dataset is prepared by Barsoum et.al. from Microsoft. FER+ dataset improves the labelling from FER dataset, have bounding box for faces in the FER dataset.

We use this improved dataset from - https://github.com/Microsoft/FERPlus/tree/master/data

# Citation

@inproceedings{BarsoumICMI2016,
    title={Training Deep Networks for Facial Expression Recognition with Crowd-Sourced Label Distribution},
    author={Barsoum, Emad and Zhang, Cha and Canton Ferrer, Cristian and Zhang, Zhengyou},
    booktitle={ACM International Conference on Multimodal Interaction (ICMI)},
    year={2016}
}